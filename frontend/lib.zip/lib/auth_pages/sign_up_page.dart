import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:powebvpn/api/google_signin_api.dart';
import 'package:powebvpn/auth_pages/logged_in_page.dart';
import 'package:powebvpn/screens/home_screen.dart';


class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        padding: const EdgeInsets.all(15),
        child:  Column(
          
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                alignment: Alignment.center,
                child: Image.asset("assets/images/logo.png", width: 280, height: 210),
              ),

              Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                  child: Image.asset('assets/images/google.png',  width: 100, height: 80),
                ),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    
                  ),
                onPressed: signIn, 
                label: const Text(
                  'Войти через Google',
                  style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold,),
                ),
                icon: const Icon(Icons.person_2, size: 32, color: Colors.white,),
              )
            ],
          ),
          ] 
          

        )
        
        
        //child: ElevatedButton(
        //  onPressed: signIn,
          //child: Text('Login with Google'),
        //),
      ),
    );
  }

  Future signIn() async {
    final GoogleSignInAccount? user = await GoogleSigninApi.login();

    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Sign in Failed')),
      );
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => HomeScreen(user: user,),
        ),
      );
    }
  }
}
