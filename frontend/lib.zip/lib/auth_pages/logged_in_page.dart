import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:powebvpn/api/google_signin_api.dart';
import 'sign_up_page.dart';

class LoggedInPage extends StatefulWidget {
  final GoogleSignInAccount? user;

  const LoggedInPage({Key? key, required this.user}) : super(key: key);

  @override
  State<LoggedInPage> createState() => _LoggedInPageState();
}

class _LoggedInPageState extends State<LoggedInPage> {
  late String name;
  late String email;
  late String googleId;
  late String accessToken;
  String? photoUrl;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserData();
  }

  Future<void> sendUserToBackend() async {
  try {
    final uri = Uri.parse('http://10.0.2.2:8000/api/google-login');
    print('Données envoyées :');
    print({
      'name': name,
      'email': email,
      'google_id': googleId,
      'avatar': photoUrl,
      'access_token': accessToken,
    });
    final response = await http.post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: jsonEncode({
        'name': name,
        'email': email,
        'google_id': googleId,
        'avatar': photoUrl,
        'access_token': accessToken,
      }),
    );

    if (response.statusCode == 200) {
      print('✅ Utilisateur enregistré avec succès');
      print('Réponse: ${response.body}');
    } else {
      print('❌ Erreur lors de l’enregistrement: ${response.statusCode}');
      print('Corps de la réponse: ${response.body}');
    }
  } catch (e) {
    print('🔥 Exception lors de l’envoi au backend: $e');
  }
}







  void fetchUserData() async {
    await Future.delayed(Duration(milliseconds: 500)); // petit délai simulé

    final user = widget.user;
    final auth = await user?.authentication;

    setState(() {
      name = user?.displayName ?? 'Имя не указано';
      email = user?.email ?? 'Электронная почта недоступна';
      googleId = user?.id ?? 'Google ID inconnu';
      accessToken = auth?.accessToken ?? 'Token introuvable';
      photoUrl = user?.photoUrl;
      isLoading = false;
    });

    await sendUserToBackend();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.chevron_left, color: Colors.white, size: 32),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Colors.orange))
          : Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 30),
                  CircleAvatar(
                    radius: 80,
                    backgroundImage: (photoUrl != null && photoUrl!.isNotEmpty)
                        ? NetworkImage(photoUrl!)
                        : const AssetImage('assets/images/avatar.jpg') as ImageProvider,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Nom: $name',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Email: $email',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Google ID: $googleId',
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Access Token:\n$accessToken',
                    style: const TextStyle(
                      color: Colors.white38,
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                    ),
                    icon: const Icon(Icons.logout, size: 32, color: Colors.white),
                    label: const Text(
                      'Отключение',
                      style: TextStyle(
                        fontSize: 19,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onPressed: () async {
                      await GoogleSigninApi.logout();
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => SignUpPage()),
                      );
                    },
                  ),
                ],
              ),
            ),
    );
  }
}
