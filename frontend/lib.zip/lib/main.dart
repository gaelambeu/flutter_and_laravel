import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:powebvpn/auth_pages/logged_in_page.dart';
import 'package:powebvpn/auth_pages/sign_up_page.dart';
import 'package:powebvpn/auth_pages/user_page.dart';
import 'package:powebvpn/payement/payment_page.dart';
import 'package:powebvpn/screens/home_screen.dart';
import 'package:powebvpn/screens/menu_screen.dart';
import 'package:powebvpn/screens/premium_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  GoogleSignInAccount? user;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  @override
  void initState() {
    super.initState();
    _checkSignIn();
  }

  Future<void> _checkSignIn() async {
    try {
      final account = await _googleSignIn.signInSilently();
      setState(() {
        user = account;
      });
    } catch (e) {
      print("Ошибка при проверке входа в систему: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: user == null ? SignUpPage() : HomeScreen(user: user!),
      routes: {
        '/signup': (context) =>  SignUpPage(),
        '/home': (context) => HomeScreen(user: user!),
        '/menu': (context) =>  MenuScreen(),
        '/premium': (context) =>  PremiumScreen(),
        '/profil': (context) => LoggedInPage(user: user),
        '/pay': (context) =>  StylishCryptoPayScreen(),

      },
    );
  }
}
